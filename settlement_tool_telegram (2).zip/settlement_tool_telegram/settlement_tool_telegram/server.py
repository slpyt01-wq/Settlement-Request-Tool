
import base64
import binascii
import json
import logging
import os
from pathlib import Path

import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

# --------------------------------------------------
# CONFIGURATION
# --------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent

load_dotenv(BASE_DIR / ".env")

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
GROUPS_FILE = BASE_DIR / "groups.json"
INDEX_FILE = BASE_DIR / "index.html"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s"
)

logger = logging.getLogger("settlement_bot")

app = FastAPI(title="Settlement Telegram Bot")


# --------------------------------------------------
# REQUEST MODEL
# --------------------------------------------------

class SendRequest(BaseModel):
    shop: str = Field(min_length=1, max_length=200)
    caption: str = Field(default="", max_length=1024)
    image_base64: str = Field(min_length=1)


# --------------------------------------------------
# LOAD TELEGRAM GROUPS
# --------------------------------------------------

def load_groups():

    try:
        data = json.loads(
            GROUPS_FILE.read_text(encoding="utf-8")
        )

    except FileNotFoundError:
        raise HTTPException(
            status_code=500,
            detail="groups.json was not found beside server.py"
        )

    except json.JSONDecodeError:
        raise HTTPException(
            status_code=500,
            detail="groups.json contains invalid JSON"
        )

    except OSError as exc:
        logger.exception("Could not read groups.json")

        raise HTTPException(
            status_code=500,
            detail="Could not read groups.json"
        )

    if not isinstance(data, dict):
        raise HTTPException(
            status_code=500,
            detail="groups.json must contain a JSON object"
        )

    return data


# --------------------------------------------------
# HOME PAGE
# --------------------------------------------------

@app.get("/")
def home():

    if not INDEX_FILE.exists():
        raise HTTPException(
            status_code=404,
            detail="index.html was not found"
        )

    return FileResponse(INDEX_FILE)


# --------------------------------------------------
# GET SHOP LIST
# --------------------------------------------------

@app.get("/api/shops")
def shops():

    groups = load_groups()

    return {
        "shops": {
            shop: True
            for shop in groups
        }
    }


# --------------------------------------------------
# SEND SETTLEMENT TO TELEGRAM
# --------------------------------------------------

@app.post("/api/send")
async def send_to_telegram(payload: SendRequest):

    # Check bot token

    if not BOT_TOKEN:
        raise HTTPException(
            status_code=500,
            detail="BOT_TOKEN is missing from .env"
        )

    # Check Shop mapping

    groups = load_groups()

    chat_id = groups.get(payload.shop)

    if not chat_id:
        raise HTTPException(
            status_code=400,
            detail=f"No Telegram group configured for Shop: {payload.shop}"
        )

    if not isinstance(chat_id, (str, int)):
        raise HTTPException(
            status_code=500,
            detail=f"Invalid Telegram group ID for Shop: {payload.shop}"
        )

    # Decode image

    try:
        photo = base64.b64decode(
            payload.image_base64,
            validate=True
        )

    except (binascii.Error, ValueError):
        raise HTTPException(
            status_code=400,
            detail="Invalid Base64 image data"
        )

    # Validate PNG

    if not photo.startswith(b"\x89PNG\r\n\x1a\n"):
        raise HTTPException(
            status_code=400,
            detail="Uploaded image is not a valid PNG"
        )

    # Check image size

    if len(photo) > 9 * 1024 * 1024:
        raise HTTPException(
            status_code=400,
            detail="Image exceeds the 9 MB limit"
        )

    # Telegram API request

    url = (
        f"https://api.telegram.org/bot"
        f"{BOT_TOKEN}/sendPhoto"
    )

    files = {
        "photo": (
            "settlement.png",
            photo,
            "image/png"
        )
    }

    data = {
        "chat_id": str(chat_id),
        "caption": payload.caption
    }

    logger.info(
        "Sending settlement image. Shop=%s",
        payload.shop
    )

    # Send request to Telegram

    try:

        async with httpx.AsyncClient(
            timeout=httpx.Timeout(45.0, connect=15.0)
        ) as client:

            response = await client.post(
                url,
                data=data,
                files=files
            )

    except httpx.TimeoutException:

        logger.exception(
            "Telegram request timed out. Shop=%s",
            payload.shop
        )

        raise HTTPException(
            status_code=502,
            detail="Telegram connection timed out. Please try again."
        )

    except httpx.RequestError as exc:

        logger.exception(
            "Telegram connection failed. Shop=%s",
            payload.shop
        )

        raise HTTPException(
            status_code=502,
            detail=f"Could not connect to Telegram: {type(exc).__name__}"
        )

    # Read Telegram response

    try:

        result = response.json()

    except ValueError:

        logger.error(
            "Telegram returned non-JSON response: HTTP %s",
            response.status_code
        )

        raise HTTPException(
            status_code=502,
            detail="Telegram returned an invalid response"
        )

    # Check Telegram result

    if not response.is_success or not result.get("ok"):

        error_code = result.get(
            "error_code",
            response.status_code
        )

        description = result.get(
            "description",
            "Telegram rejected the message"
        )

        logger.error(
            "TELEGRAM ERROR | Shop=%s | HTTP=%s | Details=%s",
            payload.shop,
            response.status_code,
            result
        )

        raise HTTPException(
            status_code=502,
            detail=(
                f"Telegram API error {error_code}: "
                f"{description}"
            )
        )

    # Successful delivery

    message_id = result["result"]["message_id"]

    logger.info(
        "SUCCESS | Shop=%s | Message ID=%s",
        payload.shop,
        message_id
    )

    return {
        "ok": True,
        "message_id": message_id,
        "shop": payload.shop,
        "message": "Settlement sent successfully"
    }


# --------------------------------------------------
# HEALTH CHECK
# --------------------------------------------------

@app.get("/api/health")
def health():

    return {
        "status": "running",
        "bot_token_configured": bool(BOT_TOKEN),
        "groups_file_exists": GROUPS_FILE.exists(),
        "index_file_exists": INDEX_FILE.exists()
    }

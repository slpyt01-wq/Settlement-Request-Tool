SETTLEMENT TOOL + TELEGRAM BOT

SETUP
1. Install Python 3.10 or newer.
2. Open Command Prompt in this folder.
3. Run: py -m venv .venv
4. Activate: .venv\Scripts\activate
5. Install: pip install -r requirements.txt
6. Rename .env.example to .env and paste your Telegram bot token. Never share this token.
7. Edit groups.json. Replace EXAMPLE_SHOP with the exact Shop name shown in your Excel file and its Telegram group chat ID. Add one entry per Shop. Example:
   {
     "BNB": "-1001234567890",
     "YETI": "-1009876543210"
   }
8. Add your bot to each Telegram group. Give it permission to send messages/photos.
9. Start the app: uvicorn server:app --host 127.0.0.1 --port 8000
10. Open http://127.0.0.1:8000 in your browser. Upload Excel, review each Shop preview, then click Send.

IMPORTANT
- The app sends one Telegram photo per Shop, with your editable message as the photo caption.
- Sending is manual only after you click Send. Uploading an Excel file does not send anything.
- Shop names in groups.json must match the Shop names in the Excel file exactly (including spaces/capitalization).
- Keep the server bound to 127.0.0.1 unless you deliberately secure it for LAN use. Do not expose this endpoint publicly.
- Keep .env and your bot token private. If the token is exposed, regenerate it with BotFather.
- Telegram group IDs are commonly negative numbers beginning -100. To obtain an ID, add a trusted bot/admin utility or inspect updates using your own bot; verify the ID before sending.
